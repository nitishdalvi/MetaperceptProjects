package com.metapercept.Collage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollageApplication {

	public static void main(String[] args) {
		SpringApplication.run(CollageApplication.class, args);
	}

}
